package com.example.IassexamTranThiMaiHien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IassexamTranThiMaiHienApplication {

	public static void main(String[] args) {
		SpringApplication.run(IassexamTranThiMaiHienApplication.class, args);
	}

}
